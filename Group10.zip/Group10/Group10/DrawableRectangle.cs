﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group10
{
    class DrawableRectangle : Primitive, IDrawable, IWritable
    {
        public DrawableRectangle(Color color, bool filled, Rectangle rectangle) : base(color, filled, rectangle) { }

        public void Draw(Graphics g)
        {
            if (filled == true)
            {
                SolidBrush sBrush = new SolidBrush(color);
                g.FillRectangle(sBrush, boundingRectangle);
            }
            else
            {
                Pen myPen = new Pen(color);
                g.DrawRectangle(myPen, boundingRectangle);
            }
        }
        public void Write(TextWriter writer)
        {
            writer.WriteLine($"{color}--{filled}--{boundingRectangle}");
        }
        public double Area()
        {
            return boundingRectangle.Height * boundingRectangle.Width;
        }
    }
}
