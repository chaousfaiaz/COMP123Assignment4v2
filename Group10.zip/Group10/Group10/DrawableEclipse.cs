﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group10
{
    class DrawableEclipse : Primitive, IDrawable
    {
        public DrawableEclipse(Color color, bool filled, Rectangle rectangle) : base(color, filled, rectangle) { }

        public void Draw(Graphics g)
        {
            if (filled == true)
            {
                SolidBrush sBrush = new SolidBrush(color);
                g.FillEllipse(sBrush, boundingRectangle);
            }
            else
            {
                Pen myPen = new Pen(color);
                g.DrawEllipse(myPen, boundingRectangle);
            }

        }
        public double Area()
        {
            return Math.PI * boundingRectangle.Height * boundingRectangle.Width;
        }
    }
}
