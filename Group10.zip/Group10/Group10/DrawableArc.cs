﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group10
{
    class DrawableArc : Primitive, IDrawable, IWritable
    {
        protected float start;
        protected float end;

        public DrawableArc(Color color, bool filled, Rectangle rectangle,
                            float start, float end) : base(color, filled, rectangle)
        {
            this.start = start;
            this.end = end;
        }

        public void Draw(Graphics g)
        {
            Pen myPen = new Pen(color);
            g.DrawArc(myPen, boundingRectangle, start, end);
        }

        public void Write(TextWriter writer)
        {
            writer.WriteLine($"{color}, {filled}, {boundingRectangle}, {start}, {end}");
        }
    }
}
